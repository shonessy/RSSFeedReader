﻿using Abp.MultiTenancy;
using RSSFeedReader.Authorization.Users;

namespace RSSFeedReader.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}
