using System.ComponentModel.DataAnnotations;

namespace RSSFeedReader.Users.Dto
{
    public class ChangeUserLanguageDto
    {
        [Required]
        public string LanguageName { get; set; }
    }
}