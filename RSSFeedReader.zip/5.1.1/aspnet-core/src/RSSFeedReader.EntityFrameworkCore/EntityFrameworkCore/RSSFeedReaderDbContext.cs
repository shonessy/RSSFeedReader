﻿using Microsoft.EntityFrameworkCore;
using Abp.Zero.EntityFrameworkCore;
using RSSFeedReader.Authorization.Roles;
using RSSFeedReader.Authorization.Users;
using RSSFeedReader.MultiTenancy;

namespace RSSFeedReader.EntityFrameworkCore
{
    public class RSSFeedReaderDbContext : AbpZeroDbContext<Tenant, Role, User, RSSFeedReaderDbContext>
    {
        /* Define a DbSet for each entity of the application */
        
        public RSSFeedReaderDbContext(DbContextOptions<RSSFeedReaderDbContext> options)
            : base(options)
        {
        }
    }
}
