﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using RSSFeedReader.MultiTenancy.Dto;

namespace RSSFeedReader.MultiTenancy
{
    public interface ITenantAppService : IAsyncCrudAppService<TenantDto, int, PagedTenantResultRequestDto, CreateTenantDto, TenantDto>
    {
    }
}

