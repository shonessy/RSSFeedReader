﻿namespace RSSFeedReader
{
    public class RSSFeedReaderConsts
    {
        public const string LocalizationSourceName = "RSSFeedReader";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
