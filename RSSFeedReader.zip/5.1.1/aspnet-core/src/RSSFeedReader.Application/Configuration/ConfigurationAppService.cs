﻿using System.Threading.Tasks;
using Abp.Authorization;
using Abp.Runtime.Session;
using RSSFeedReader.Configuration.Dto;

namespace RSSFeedReader.Configuration
{
    [AbpAuthorize]
    public class ConfigurationAppService : RSSFeedReaderAppServiceBase, IConfigurationAppService
    {
        public async Task ChangeUiTheme(ChangeUiThemeInput input)
        {
            await SettingManager.ChangeSettingForUserAsync(AbpSession.ToUserIdentifier(), AppSettingNames.UiTheme, input.Theme);
        }
    }
}
