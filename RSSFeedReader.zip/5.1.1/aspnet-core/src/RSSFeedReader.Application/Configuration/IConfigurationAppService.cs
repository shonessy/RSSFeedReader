﻿using System.Threading.Tasks;
using RSSFeedReader.Configuration.Dto;

namespace RSSFeedReader.Configuration
{
    public interface IConfigurationAppService
    {
        Task ChangeUiTheme(ChangeUiThemeInput input);
    }
}
