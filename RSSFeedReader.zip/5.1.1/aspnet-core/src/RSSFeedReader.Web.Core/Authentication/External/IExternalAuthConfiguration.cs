﻿using System.Collections.Generic;

namespace RSSFeedReader.Authentication.External
{
    public interface IExternalAuthConfiguration
    {
        List<ExternalLoginProviderInfo> Providers { get; }
    }
}
