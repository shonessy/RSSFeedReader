﻿using Abp.Authorization;
using RSSFeedReader.Authorization.Roles;
using RSSFeedReader.Authorization.Users;

namespace RSSFeedReader.Authorization
{
    public class PermissionChecker : PermissionChecker<Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {
        }
    }
}
