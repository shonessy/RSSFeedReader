﻿using System.Threading.Tasks;
using Abp.Application.Services;
using RSSFeedReader.Sessions.Dto;

namespace RSSFeedReader.Sessions
{
    public interface ISessionAppService : IApplicationService
    {
        Task<GetCurrentLoginInformationsOutput> GetCurrentLoginInformations();
    }
}
