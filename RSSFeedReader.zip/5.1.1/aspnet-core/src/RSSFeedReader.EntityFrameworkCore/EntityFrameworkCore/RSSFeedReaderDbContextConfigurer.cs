using System.Data.Common;
using Microsoft.EntityFrameworkCore;

namespace RSSFeedReader.EntityFrameworkCore
{
    public static class RSSFeedReaderDbContextConfigurer
    {
        public static void Configure(DbContextOptionsBuilder<RSSFeedReaderDbContext> builder, string connectionString)
        {
            builder.UseSqlServer(connectionString);
        }

        public static void Configure(DbContextOptionsBuilder<RSSFeedReaderDbContext> builder, DbConnection connection)
        {
            builder.UseSqlServer(connection);
        }
    }
}
